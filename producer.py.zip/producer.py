import json

import boto3

import uuid

DATA_STREAM_NAME = 'SpotiguysKinesisDataStream'
BUCKET_NAME = 'spotiguys-bucket-1-test'


def lambda_handler(event, context):
    id = event['id']
    
    kinesis = boto3.client('kinesis')
    s3 = boto3.client('s3')
    
    partition_key = str(uuid.uuid4())
    
    audio_features = json.loads(s3.get_object(Bucket=BUCKET_NAME, Key=f'{id}/audio-features.json')['Body'].read().decode('utf-8'))
        
    for feature in audio_features:
        # Randomly generates a PartitionKey, which allows for different datasets in a single shard
        response = kinesis.put_record(StreamName=DATA_STREAM_NAME, Data=json.dumps(feature), PartitionKey=partition_key)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
