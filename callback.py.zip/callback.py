import json
import urllib3
import spotipy
import boto3

CLIENT_ID = '18f485d7a7144f5aaff8be68dfa5d40e'
CLIENT_SECRET = '1d6e91216124474c9a1f3e71da12edd2'

BUCKET_NAME = 'spotiguys-bucket-1-test'

SCOPE = 'user-read-private playlist-read-private playlist-modify-private playlist-modify-public'

http = urllib3.PoolManager()


def lambda_handler(event, context) -> dict:
    base_url = 'https://api.spotiguys.tk/'
    
    oauth = spotipy.SpotifyOAuth(client_id=CLIENT_ID,
                                 client_secret=CLIENT_SECRET,
                                 redirect_uri=base_url + 'callback',
                                 scope=SCOPE)
    
    print(event)
    access_token = event['access_token']
    sp = spotipy.Spotify(auth=access_token, requests_timeout=15, retries=20)
    
    playlists = sp.current_user_playlists()
    
    user_id = sp.current_user()['id']

    songs = []
    for playlist in playlists['items']:
        for song in sp.playlist_items(playlist['id'])['items']:
            songs.append(song['track'])

    audio_features = []
    song_ids = []
    for i in range(len(songs)):
        if(songs[i]['id'] is not None):
            song_ids.append(songs[i]['id'])
        if i % 100 == 0:
            for feature in sp.audio_features(tracks=song_ids):
                reduced_feature = {
                    'total': len(songs),
                    'acousticness': feature['acousticness'],
                    'danceability': feature['danceability'],
                    'energy': feature['energy'],
                    'instrumentalness': feature['instrumentalness'],
                    'liveness': feature['liveness'],
                    'loudness': feature['loudness'],
                    'speechiness': feature['speechiness'],
                    'tempo': feature['tempo'],
                    'valence': feature['valence'],
                    'uri': feature['uri'],
                    'user_id' : user_id
                }
                
                audio_features.append(reduced_feature)
            song_ids = []

    for feature in sp.audio_features(tracks=song_ids):
        reduced_feature = {
            'total': len(songs),
            'acousticness': feature['acousticness'],
            'danceability': feature['danceability'],
            'energy': feature['energy'],
            'instrumentalness': feature['instrumentalness'],
            'liveness': feature['liveness'],
            'loudness': feature['loudness'],
            'speechiness': feature['speechiness'],
            'tempo': feature['tempo'],
            'valence': feature['valence'],
            'uri': feature['uri'],
            'user_id' : user_id
        }
        
        audio_features.append(reduced_feature)

    s3 = boto3.client('s3')
    
    upload_byte_stream = bytes(json.dumps(audio_features).encode('utf-8'))
    
    s3.put_object(Bucket=BUCKET_NAME, Key=f'{user_id}/audio-features.json', Body=upload_byte_stream)
    
    return {
        'statusCode': 200,
        'body': json.dumps(audio_features)
    }