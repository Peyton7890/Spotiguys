import base64
import json
import boto3

def lambda_handler(event, context):
    DATA_STREAM_NAME = 'SpotiguysKinesisDataStream'
    BUCKET_NAME = 'spotiguys-finished-playlist-bucket-test'
    danceability = 0.0
    energy = 0.0
    valence = 0.0
    songs = []

    for record in event['Records']:
        # Kinesis data is base64 encoded so decode here
        payload = base64.b64decode(record['kinesis']['data']).decode('utf-8')
        
        formattedPayload = json.loads(payload)
        
        if "danceability" in formattedPayload:
            danceability += formattedPayload["danceability"]
        if "energy" in formattedPayload:
            energy += formattedPayload["energy"]
        if "valence" in formattedPayload:
            valence += formattedPayload["valence"]
        songs.append({'user_id': formattedPayload["user_id"], 'uri': formattedPayload["uri"], 'danceability': formattedPayload["danceability"], 'energy': formattedPayload["energy"], 'valence': formattedPayload["valence"]})
            
    danceability /= len(event['Records'])
    energy /= len(event['Records'])
    valence /= len(event['Records'])
    
    songs.append({'user_id': "avg", 'uri': "avg", 'danceability': danceability, 'energy': energy, 'valence': valence})
    
    s3 = boto3.client('s3')
    upload_byte_stream = bytes(json.dumps(songs).encode('utf-8'))
    
    jsonName = str(int(danceability*10000000) + int(energy*10000000) + int(valence*10000000)) + '.json'
    
    s3.put_object(Bucket=BUCKET_NAME, Key=jsonName, Body=upload_byte_stream)
    
    print(jsonName)
    print(energy)
        
    return 'Successfully processed {} records.'.format(len(event['Records']))