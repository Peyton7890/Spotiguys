import json
import urllib3
import spotipy
import boto3
from collections import OrderedDict

CLIENT_ID = '18f485d7a7144f5aaff8be68dfa5d40e'
CLIENT_SECRET = '1d6e91216124474c9a1f3e71da12edd2'
BUCKET_NAME = 'spotiguys-finished-playlist-bucket-test'
PLAYLIST_NAME = 'Spotiguys Playlist'
SCOPE = 'user-read-private playlist-read-private playlist-modify-private playlist-modify-public'
http = urllib3.PoolManager()


def lambda_handler(event, context) -> dict:
    danceability=0.0
    energy=0.0
    valence=0.0
    numShards = 0;
    songs = []
    playlist = []
    token_info = event['access_token']
    api_gateway = boto3.client('apigateway')
    s3 = boto3.client('s3')
    
    # Get all songs
    jsonFiles = s3.list_objects(Bucket=BUCKET_NAME)['Contents']
    for file in jsonFiles:
        userSongs = json.loads(s3.get_object(Bucket=BUCKET_NAME, Key=file['Key'])['Body'].read().decode('utf-8'))
        for s in userSongs:
            songs.append(s)
    
    # Authenticate user
    sp = spotipy.Spotify(auth=token_info, requests_timeout=15, retries=20)
    
    # Find total average
    for s in songs:
        if "user_id" in s:
            if s["user_id"] == "avg":
                danceability += s["danceability"]
                energy += s["energy"]
                valence += s["valence"]
                numShards += 1
                
    danceability /= numShards
    energy /= numShards
    valence /= numShards
                
    # Filter songs
    avgFactor = 0.05
    while len(playlist) < 20 or len(playlist) > 100:
        playlist = []
        for s in songs:
            if "user_id" in s:
                if s["user_id"] != "avg":
                    if s["danceability"] > danceability+avgFactor or s["danceability"] < danceability-avgFactor:
                        continue
                    if s["energy"] > energy+avgFactor or s["energy"] < energy-avgFactor:
                        continue
                    if s["valence"] > valence+avgFactor or s["valence"] < valence-avgFactor:
                        continue
                    playlist.append(s["uri"])
                    
        playlist = list(OrderedDict.fromkeys(playlist))
        
        if len(playlist) < 20:
            avgFactor += 0.05
        else:
           avgFactor -= 0.04 
    
    # Create playlist
    sp.user_playlist_create(sp.current_user()['id'], PLAYLIST_NAME)
    
    userPlaylists = sp.current_user_playlists()
    for p in userPlaylists['items']:
        if p['name'] == PLAYLIST_NAME:
            sp.playlist_add_items(p['id'], playlist)

    print('Number of songs ' + str(len(songs)))
    print('avg factor ' + str(avgFactor))
    print('Playlist length ' + str(len(playlist)))
    print(playlist)
    
    bucket = boto3.resource('s3').Bucket('spotiguys-finished-playlist-bucket-test')
    bucket.objects.all().delete()
    
    return {
        'statusCode': 200,
        'body': json.dumps(playlist)
    }